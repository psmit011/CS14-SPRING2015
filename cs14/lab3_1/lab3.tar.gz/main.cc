#include <iostream>
#include <stack>
#include "lab3.h"
using namespace std;

int main(){
	cout<<"Hello World"<<endl;
	cout<<"Testing constructor"<<endl;
	TwoStackFixed<int> stack1(500, 6);
	cout<<"printing empty stack"<<endl;
	for(int i = 0; i < 5; i++){
		cout<<" Cool "<<endl;
	}

	cout<<"Testing push Stack 1: 1,2,3,4,5"<<endl;
	stack1.pushStack1(1);
	stack1.pushStack1(2);
	stack1.pushStack1(3);
	stack1.pushStack1(4);
	stack1.pushStack1(5);

	cout<<"Testing pop Stack 1"<<endl;
	stack1.popStack1();
	stack1.popStack1();
	stack1.popStack1();
	stack1.popStack1();
	stack1.popStack1();
	stack1.popStack1();

	cout<<"Testing push Stack 2: 1,2,3,4,5"<<endl;
	stack1.pushStack2(1);
	stack1.pushStack2(2);
	stack1.pushStack2(3);
	stack1.pushStack2(4);
	stack1.pushStack2(5);

	cout<<"Testing pop Stack 2"<<endl;
	stack1.popStack2();
	stack1.popStack2();
	stack1.popStack2();
	stack1.popStack2();
	stack1.popStack2();
	stack1.popStack2();

	cout<<"tesitng the tower of Hanoi with five moves"<<endl;
	stack<int> A, B, C;
	for(int i = 5; i > 0; i--){
		A.push(i);
	}
	cout<<"stack created"<<endl;
	showTowerStates(5, A, B, C);
	
	cout<<"tesitng the tower of Hanoi with five moves"<<endl;
	stack<int> A1, B1, C1;
	for(int i = 4; i > 0; i--){
		A1.push(i);
	}
	cout<<"stack created"<<endl;
	showTowerStates(4, A1, B1, C1);
	
	return 0;
}
